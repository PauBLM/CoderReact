import React from "react";
import cartwidget from "./cartwidget";
import Navbaritem from "./Navbaritem";

const Navbar = () => {
    return (
        <header>
            <nav>
                <Navbaritem name="Inicio"/>
                <Navbaritem name="Sobre nosotros"/>
                <Navbaritem name="Contacto"/>
                <cartwidget/> 
            </nav>
        </header>
    )
}

export default Navbar;


const ItemListContainer = () => {
    return (
        <div>
            

        </div>
    )
}

export default ItemListContainer;