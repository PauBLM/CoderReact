import React from 'react'

const Navbaritem = ({name}) => {
    return (
        <li>
            <a>{name}</a>
        </li>
    )
}

export default Navbaritem
