import './App.css';
import Navbar from './components/Navbar';
import ItemListContainer from './components/ItemListContainer';

function App() {
  return <>
  <Navbar> </Navbar>;
  <ItemListContainer></ItemListContainer>
  </>;
}

export default App;
