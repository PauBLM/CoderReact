import React from 'react'
import cartIcon from "../assets/icon/shopping_cart_black_24dp.svg"

const CartWidget = () => {
    return (
        <>
            <div>
                <img src={cartIcon} />
            </div>
            
        </>
    )
}

export default CartWidget;
