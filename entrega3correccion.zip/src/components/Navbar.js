import React from "react";
import CartWidget from "./CartWidget";
import Navbaritem from "./Navbaritem";

const Navbar = () => {
    return (
        <header>
            <nav>
                <Navbaritem name="Inicio"/>
                <Navbaritem name="Sobre nosotros"/>
                <Navbaritem name="Contacto"/>
                <CartWidget/> 
            </nav>
        </header>
    )
}

export default Navbar;

