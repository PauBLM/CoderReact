import logo from './logo.svg';
import './App.css';
import Navbar from './components/Navbar';

function App() {
  return <>
  <Navbar> </Navbar>;
    <h2>Semana de hot sale</h2>
  </>;
}

export default App;
