import React from "react"
import Navbar from "./components/Navbar"

const Navbar = () => {
    return <div Esto es un intento></div>
}

export default Navbar;